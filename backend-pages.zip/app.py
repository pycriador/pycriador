import os
import time
from flask import Flask, abort, request, jsonify, g, url_for, render_template, flash, redirect
from flask_sqlalchemy import SQLAlchemy
from flask_httpauth import HTTPBasicAuth
import jwt
from werkzeug.security import generate_password_hash, check_password_hash

from flask_migrate import Migrate

# initialization

app = Flask(__name__)
basedir = os.path.abspath(os.path.dirname(__file__))

#Hello World
PORT = 8080
MESSAGE = "Sucesso"

#import os
#os.urandom(24).hex()


app.config['SECRET_KEY'] = 'kdKGy40mmvJzd08SpyMze8YQzc2SHPCh'
#pip install mariadb
#mariadb+mariadbconnector://<user>:<password>@<host>[:<port>]/<dbname>
#pip install pymysql
#mysql+pymysql://<username>:<password>@<host>/<dbname>[?<options>]
#pip install mysql-connector-python
#mysql+mysqlconnector://<user>:<password>@<host>[:<port>]/<dbname>
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://admin:2A1N3fjvkB1gW@free-the-freela-test.cmdoglpvqxlh.us-east-1.rds.amazonaws.com/freethefreela'
app.config['SQLALCHEMY_ENGINE_OPTIONS'] = {'pool_size': 10, 'pool_recycle': 120, 'pool_pre_ping': True }

db = SQLAlchemy(app)
auth = HTTPBasicAuth()
migrate = Migrate(app, db)

messages = [{'title': 'Bem-víndo',
             'content': 'Página de teste do BackEnd'},
            {'title': 'Mensagem de teste',
             'content': 'Conteúdo da mensagem'}
            ]


#Cadastro de usuário
class User(db.Model):
    __tablename__ = 'cadastro'
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(128))
    email = db.Column(db.String(128))
    habilidade = db.Column(db.String(128))
    telefone = db.Column(db.String(128))

@app.route('/api/createuser', methods=['POST'])
def CreateUser():
    nome = request.json.get('nome')
    email = request.json.get('email')
    habilidade = request.json.get('habilidade')
    telefone = request.json.get('telefone')

    user = User(nome=nome , email=email, habilidade=habilidade, telefone=telefone)

    db.session.add(user)
    db.session.commit()
    return (jsonify({'username': user.nome}), 201,
    {'Location': url_for('get_user', id=user.id, _external=True)})


@app.route('/api/users/<int:id>')
def get_user(id):
    user = User.query.get(id)
    if not user:
        abort(400)
    return jsonify({'username': user.username})


@app.route('/cadastro/', methods=('GET', 'POST'))
def cadastro():
    if request.method == 'POST':
        nome = request.form['nome']
        email = request.form['email']
        habilidade = request.form['habilidade']
        telefone = request.form['telefone']

        user = User(nome=nome , email=email, habilidade=habilidade, telefone=telefone)

        db.session.add(user)
        db.session.commit()

        #return (jsonify({'username': user.nome}), 201,
        #    {'Location': url_for('get_user', id=user.id, _external=True)})

    return render_template('cadastro.html')

#Modelo de formulário
#https://www.digitalocean.com/community/tutorials/how-to-use-web-forms-in-a-flask-application
@app.route('/criar/', methods=('GET', 'POST'))
def create():
    if request.method == 'POST':
        title = request.form['title']
        content = request.form['content']

        if not title:
            flash('Title is required!')
        elif not content:
            flash('Content is required!')
        else:
            messages.append({'title': title, 'content': content})
            return redirect(url_for('index'))
    return render_template('create.html')

@app.route('/mensagens/')
def index():
    return render_template('index.html', messages=messages)

@app.route('/sobre/')
def sobre():
    return render_template('sobre.html')

@app.route("/")
def root():
    return redirect(url_for('index'))

#Aplicação principal
def create_app():
    app = Flask(__name__)
    db.init_app(app)
    migrate.init_app(app, db)
    return app

#if __name__ == "__main__":
#  app.run(debug=True, host="0.0.0.0", port=PORT)

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
        app.run(debug=True, host="0.0.0.0", port=PORT)