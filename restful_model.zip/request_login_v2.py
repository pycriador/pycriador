import requests
import json

data = { 'nome': 'Willian Rosa', 'email': 'willian.o.jesus@gmail.com', 'habilidade': 'Python + Pandas',  'telefone' : '1198888-7777'}
#headers = { "Content-Type" : "application/json" }
headers = {}

#Criar usuário
#response = requests.post('https://backend-freethefreela.herokuapp.com/api/createuser',json=data, headers=headers)
response = requests.post('http://localhost:5000/api/createuser',json=data, headers=headers)

#Logar e receber resposta de volta
#response = requests.get('http://localhost:5000/api/checklogin',auth=('willian.o.jesus@gmail.com', 'willian'))

#Gerar token
#response = requests.get('https://freethefreela-python-test.herokuapp.com/api/token',auth=('willian', 'willian'))

#Logar com o token
#token = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MSwiZXhwIjoxNjY2MDQ3Nzk5LjM2NjIzNDh9.kfhUhCcqmoDwgDuYztjtfdLwL0Or8tnTumLtCkew2Gw'
#response = requests.get('https://freethefreela-python-test.herokuapp.com/api/resource',auth=(token, token))


print("Status Code", response.status_code)
#print(response)
print("JSON Response ", response.json())